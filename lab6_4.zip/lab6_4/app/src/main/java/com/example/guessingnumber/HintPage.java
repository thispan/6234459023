package com.example.guessingnumber;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class HintPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hint_page);

        final EditText userGuessInput = findViewById(R.id.enterNumber);
        Button guessButton = findViewById(R.id.guessButton);
        final TextView hint = findViewById(R.id.hint);
        final int randomInt = getIntent().getExtras().getInt("com.lab6_4.guessingnumber.randomint");

        guessButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (CheckInput.isInteger(userGuessInput.getText().toString())){
                    int userGuess = Integer.parseInt(userGuessInput.getText().toString());
                    if (userGuess >= 1 && userGuess <= 100){
                        if (userGuess > randomInt){
                            hint.setText("Your guess is too hight!");
                        }
                        else if (userGuess < randomInt){
                            hint.setText("Your guess is too low!");
                        }
                        else {
                            Intent startIntent = new Intent(getApplicationContext(),LastPage.class);
                            startActivity(startIntent);
                        }
                    }
                    else {
                        hint.setText("Invalid input.");
                    }
                }
                else{
                    hint.setText("Invalid input.");
                }
            }
        });
    }
}
